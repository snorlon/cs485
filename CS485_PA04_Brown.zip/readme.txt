Instructions:

    For all parts

        To setup makefile:
            cmake CMakeLists.txt
            cmake CMakeLists.txt
                second time resolves c++11 not being applied

    reset; make clean; make
    /DisplayImage
